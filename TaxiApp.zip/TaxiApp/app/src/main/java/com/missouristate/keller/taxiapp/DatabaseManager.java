package com.missouristate.keller.taxiapp;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DatabaseManager  extends SQLiteOpenHelper {


    private static final String DATABASE_NAME = "taxiDB";
    private static final int DATABASE_VERSION = 1;
    //private static final String ID = "id";
    private static final String TABLE_TAXI = "taxi";
    private static final String NAME = "name";
    private static final String BASEPRICE = "baseprice" ;
    private static final String PRICE_MILE = "price_mile";


    public DatabaseManager (Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String sqlCreate = "create table " + TABLE_TAXI + "( " + NAME;
        sqlCreate += " text, " + BASEPRICE;
        sqlCreate +=  " real, " + PRICE_MILE + " real )";

        db.execSQL(sqlCreate);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        // Drop old table if it exists
        db.execSQL("drop table if exists " + TABLE_TAXI);
        // Re-create tables
        onCreate(db);

    }

   /* public void insert (Taxi taxi) {

        SQLiteDatabase db = this.getWritableDatabase();
        String sqlInsert = "insert into " + TABLE_TAXI;
        sqlInsert += " values (null, '" + taxi.getName();
        sqlInsert += "','" + taxi.getBasePrice();
        sqlInsert += "','" + taxi.getPrice_mile();

        db.execSQL(sqlInsert);
        db.close();
    } */

    public ArrayList<Taxi> selectAll () {

        String sqlQuery = "select * from " + TABLE_TAXI;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(sqlQuery, null);

        ArrayList<Taxi> taxies = new ArrayList<Taxi>();
        while (cursor.moveToNext()) {
            Taxi currentTaxi
                    = new Taxi(cursor.getString(0),
                    cursor.getDouble(1), cursor.getDouble(2));
            taxies.add(currentTaxi);
        }
        db.close();
        return taxies;
    }
    public ArrayList<Taxi> selectLowest () {

        String sqlQuery = "select * from " + TABLE_TAXI;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(sqlQuery, null);

        ArrayList<Taxi> taxies = new ArrayList<Taxi>();
        while (cursor.moveToNext()) {
            Taxi currentTaxi
                    = new Taxi(cursor.getString(0),
                    cursor.getDouble(1), cursor.getDouble(2));
            taxies.add(currentTaxi);
       // selectLowest base price and price per mile code?

            }
        db.close();
        return taxies;
    }

}
