package com.missouristate.keller.taxiapp;

class Taxi {

    private double price_mile;
    private double basePrice;
    private String name;

    public Taxi (String newName, double newBasePrice, double newPrice_Mile) {
        setName (newName);
        setBasePrice (newBasePrice);
        setPrice_Mile (newPrice_Mile);
    }

    private void setPrice_Mile(double newPrice_mile) {
        price_mile = newPrice_mile;
    }

    private void setBasePrice(double newBasePrice) {
        basePrice = newBasePrice;
    }

    private void setName(String newName) {
        name = newName;
    }

    public double getPrice_mile () {
        return price_mile;
    }

    public double getBasePrice () {
        return basePrice;

    }

    public String getName () {
        return name;
    }

    public String toString () {
        return name + ": " + basePrice + ": " + price_mile;
    }
}
