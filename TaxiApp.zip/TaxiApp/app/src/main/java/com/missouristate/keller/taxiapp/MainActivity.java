package com.missouristate.keller.taxiapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    DatabaseManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        dbManager = new DatabaseManager(this);
    }

    protected void onResume () {
        super.onResume();
        createView();
    }

    private void createView() {
        ArrayList<Taxi> taxis = dbManager.selectAll();
        RelativeLayout layout = new RelativeLayout(this);
        ScrollView scrollView = new ScrollView(this);
        RadioGroup group = new RadioGroup(this);
        for (Taxi taxi : taxis) {
            TextView friendList = new TextView(this);
            taxiList.setId(taxi.getId());
            taxiList.setText(taxi.get() + taxi.get() + taxi.get()); //concatenate name + base price + price per mile
            taxiList.setTextSize(20);
            group.addView(taxiList);
        }

        scrollView.addView(group);
        layout.addView(scrollView);

        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        params.addRule(RelativeLayout.CENTER_HORIZONTAL);
        params.setMargins(0, 0, 0, 50);
        layout.setPadding(50,50,50,50);

        setContentView(layout);
    }
    }

}
